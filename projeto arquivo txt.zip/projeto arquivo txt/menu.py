import cores
def menu():
    menu=(f'{"-="*10}\n{"MENU":^20}\n{"-="*10}\n1-ADICIONAR PESSOA\n2-LER PESSOAS\n3-SAIR\n4-PESSOA MAIS VELHA\n5-PESSOA MAIS NOVA\n6-REMOVER ARQUIVO')
    print(cores.pintura(C_L=35,msg=menu))
    escolha=int(input(cores.pintura(C_L=34,msg='SUA ESCOLHA: ')))
    return escolha
